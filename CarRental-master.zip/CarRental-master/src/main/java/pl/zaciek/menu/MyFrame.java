package pl.zaciek.menu;

import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {

    public MyFrame() {
        super("RENTCAR - Wypożyczalnia samochodów");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600,300);
        setLocation(60,60);
        setLayout(new GridBagLayout());




        add(new JButton("Lista aut"));
        add(new JLabel("       "));
        add(new JButton("Wypożycz samochód"));
        add(new JLabel("       "));
        add(new JLabel("strefa użytkownika :"));
        add(new JLabel("       "));
        add(new JLabel("       "));
        add(new JButton("Logowanie"));
        add(new JLabel("       "));
        add(new JButton("Wyloguj"));


        setVisible(true);
    }
}
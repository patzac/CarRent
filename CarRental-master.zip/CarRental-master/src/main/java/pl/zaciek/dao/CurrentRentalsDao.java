package pl.zaciek.dao;

import pl.zaciek.model.CurrentRentals;

public class CurrentRentalsDao extends AbstractDao<CurrentRentals> {
    public CurrentRentalsDao() {super(CurrentRentals.class);}
}

package pl.zaciek.dao;

import pl.zaciek.model.Customer;

public class CustomerDao extends AbstractDao<Customer> {
    public CustomerDao() {super(Customer.class);}
}

package pl.zaciek.dao;

import pl.zaciek.model.Car;

public class CarDao extends AbstractDao<Car> {
    public CarDao() {super(Car.class); }


}

package pl.zaciek;

import pl.zaciek.dao.CarDao;
import pl.zaciek.dao.CurrentRentalsDao;
import pl.zaciek.dao.CustomerDao;

public class App {

    public static void main(String[] args) {

        CarDao carDao = new CarDao();
        CurrentRentalsDao currentRentalsDao = new CurrentRentalsDao();
        CustomerDao customerDao = new CustomerDao();




    }
}
